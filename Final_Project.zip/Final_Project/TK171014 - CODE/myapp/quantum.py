
from qiskit import QuantumCircuit, execute, Aer

# Function to create a random key using a quantum circuit
def create_random_key(n_bits):
    qc = QuantumCircuit(n_bits, n_bits)
    for i in range(n_bits):
        qc.h(i)  # Apply Hadamard gate to create superposition
    qc.measure(range(n_bits), range(n_bits))
    backend = Aer.get_backend('qasm_simulator')
    result = execute(qc, backend, shots=1).result()
    counts = result.get_counts()
    key = list(counts.keys())[0]
    return key

# Function to convert text to binary
def text_to_binary(text):
    return ''.join(format(ord(char), '08b') for char in text)

# Function to convert binary to text
def binary_to_text(binary):
    return ''.join(chr(int(binary[i:i+8], 2)) for i in range(0, len(binary), 8))

# Function to XOR data with key for encryption
def encrypt_text(text, key):
    binary_text = text_to_binary(text)
    return ''.join([str(int(binary_text[i]) ^ int(key[i % len(key)])) for i in range(len(binary_text))])

# Function to XOR encrypted data with key for decryption
def decrypt_text(encrypted_text, key):
    decrypted_binary = ''.join([str(int(encrypted_text[i]) ^ int(key[i % len(key)])) for i in range(len(encrypted_text))])
    return binary_to_text(decrypted_binary)


# Example usage
# text = 'Hello Quantum gvasfsafawf wfaswfwsd fawdf weefqwedwq wefwqdqw wefqwedwq wefQWEDWQED WEFQWD FWEDEQW EFGREWG ERGVWEF D'  # Example text to be encrypted
# key = create_random_key(len(text_to_binary(text)))
# encrypted_text = encrypt_text(text, key)

# print("Text:", text)
# print("Key:", key)
# print("Encrypted Text:", encrypted_text)


# # Example usage
# decrypted_text = decrypt_text(encrypted_text, key)

# print("Encrypted Text:", encrypted_text)
# print("Key:", key)
# print("Decrypted Text:", decrypted_text)
