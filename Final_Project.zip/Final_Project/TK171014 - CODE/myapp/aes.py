from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes
import base64

# Function for AES Encryption
def aes_encrypt(key: bytes, plaintext: str) -> str:
    # Generate a random IV (Initialization Vector)
    iv = get_random_bytes(AES.block_size)
    
    # Create AES cipher object
    cipher = AES.new(key, AES.MODE_CBC, iv)
    
    # Pad the plaintext to be a multiple of the block size
    padded_data = pad(plaintext.encode(), AES.block_size)
    
    # Encrypt the padded plaintext
    ciphertext = cipher.encrypt(padded_data)
    
    # Combine IV and ciphertext for transmission
    encrypted_message = base64.b64encode(iv + ciphertext).decode('utf-8')
    
    return encrypted_message

# Function for AES Decryption
def aes_decrypt(key: bytes, encrypted_message: str) -> str:
    # Decode the base64 encoded ciphertext
    encrypted_data = base64.b64decode(encrypted_message)
    
    # Extract the IV and the ciphertext
    iv = encrypted_data[:AES.block_size]
    ciphertext = encrypted_data[AES.block_size:]
    
    # Create AES cipher object
    cipher = AES.new(key, AES.MODE_CBC, iv)
    
    # Decrypt the ciphertext
    decrypted_data = unpad(cipher.decrypt(ciphertext), AES.block_size)
    
    # Return the plaintext as a string
    return decrypted_data.decode('utf-8')

# # Example usage
# if __name__ == "__main__":
#     # Define a 16-byte (128-bit) key (for AES-128)
#     key = get_random_bytes(16)  # You can also use a static key
    
#     plaintext = "This is a secret message!"
    
#     print(f"Original Message: {plaintext}")
    
#     # Encrypt the message
#     encrypted_message = aes_encrypt(key, plaintext)
#     print(f"Encrypted Message: {encrypted_message}")
#     print(type(key.hex()))
#     print(type(encrypted_message))
#     hex_key = key.hex()
#     nkey=bytes.fromhex(hex_key)
#     print(type(nkey))
#     # Decrypt the message
#     decrypted_message = aes_decrypt(nkey, encrypted_message)
#     print(f"Decrypted Message: {decrypted_message}")
