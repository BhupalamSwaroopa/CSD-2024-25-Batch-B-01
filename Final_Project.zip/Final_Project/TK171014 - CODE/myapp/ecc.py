



from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import os

# Generate ECC private key
private_key = ec.generate_private_key(ec.SECP256R1())

# Serialize private key to PEM format
private_pem = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.TraditionalOpenSSL,
    encryption_algorithm=serialization.NoEncryption()
)

# Serialize public key to PEM format
public_key = private_key.public_key()
public_pem = public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)

# Load private key from PEM
loaded_private_key = serialization.load_pem_private_key(
    private_pem,
    password=None
)

# Load public key from PEM
loaded_public_key = serialization.load_pem_public_key(public_pem)

# Encrypt data
def encrypt_message(public_key, message):
    # Get the public key in a format that can be used for key exchange
    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    
    # Use ECDH for key exchange
    shared_key = loaded_private_key.exchange(ec.ECDH(), serialization.load_pem_public_key(public_key_bytes))
    
    # Derive a key using PBKDF2 or other KDF
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b'salt',
        iterations=100000,
    )
    key = kdf.derive(shared_key)
    
    # Pad the message using PKCS#7
    padder = padding.PKCS7(128).padder()
    padded_message = padder.update(message) + padder.finalize()
    
    # Encrypt the message using AES
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    encrypted_message = encryptor.update(padded_message) + encryptor.finalize()
    
    return iv + encrypted_message

# Decrypt data
def decrypt_message(private_key, encrypted_message):
    # Get the public key in a format that can be used for key exchange
    public_key_bytes = loaded_public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    
    # Use ECDH for key exchange
    shared_key = private_key.exchange(ec.ECDH(), serialization.load_pem_public_key(public_key_bytes))
    
    # Derive a key using PBKDF2 or other KDF
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b'salt',
        iterations=100000,
    )
    key = kdf.derive(shared_key)
    
    # Decrypt the message using AES
    iv = encrypted_message[:16]
    encrypted_message = encrypted_message[16:]
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    decrypted_padded_message = decryptor.update(encrypted_message) + decryptor.finalize()
    
    # Unpad the message using PKCS#7
    unpadder = padding.PKCS7(128).unpadder()
    unpadded_message = unpadder.update(decrypted_padded_message) + unpadder.finalize()
    
    return unpadded_message

# # Example usage
# message = b"Hello shiva "
# encrypted_message = encrypt_message(loaded_public_key, message)
# decrypted_message = decrypt_message(loaded_private_key, encrypted_message)
# print(encrypted_message)
# print(decrypted_message)