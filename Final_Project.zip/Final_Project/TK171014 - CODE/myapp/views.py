from django.shortcuts import render, redirect
from django.contrib import messages
from . models import *
import os
from django.contrib.auth import authenticate, login as auth_login
import uuid
from .ecc import *
import random
from django.conf import settings
from django.core.mail import send_mail
import base64
from . aes import *
from . quantum import *



# templates
INDEXPAGE = "index.html"
loginpage = "login.html"
cloudhomepage = 'cloudhome.html'
viewuseracpt = 'viewuseracpt.html'
viewowneracpt = 'viewowneracpt.html'
userhome = 'userhome.html'
ownerhomepage = 'ownerhome.html'
userhomepage = 'userhome.html'
uploaddata = 'upload.html'
viewmyfile = 'viewourfile.html'
viewalfile = "viewallfile.html"
viewresponsefile = 'viewresponse.html'
viewrequestfile = 'viewrequest.html'
viewcloudrequset = "cloudresponse.html"


def index(req):
    return render(req, INDEXPAGE)



def login(request):
    if request.method == "POST":
        login_type = request.POST['login_type']
        email = request.POST['email']
        password = request.POST['password']

        if not login_type or not email or not password:
            messages.error(request, "All fields are required.")
            return render(request, loginpage)

        if login_type == "cloudserver":
            if email == "cloud@gmail.com" and password == "cloud":
                request.session['email'] = email
                request.session['name'] = 'Cloud Server Admin'
                return render(request, cloudhomepage)
            else:
                messages.error(request, 'Invalid cloud server credentials.')
                return render(request, loginpage)

        elif login_type == "user":
            try:
                user = userreg.objects.get(email=email, password=password, status='Activated')
                request.session['email'] = user.email
                request.session['name'] = user.name
                # print(user.name)
                return render(request, userhomepage, {'user': user})
            except userreg.DoesNotExist:
                messages.error(request, "Invalid user credentials or account not activated.")
                return render(request, loginpage)

        elif login_type == "owner":
            try:
                owner = ownerreg.objects.get(email=email, password=password, status='Activated')
                request.session['email'] = owner.email
                request.session['name'] = owner.name
                return render(request, ownerhomepage, {'owner': owner})
            except ownerreg.DoesNotExist:
                messages.error(request, "Invalid owner credentials or account not activated.")
                return render(request, loginpage)
        else:
            messages.error(request, "Invalid login type selected.")
            return render(request, loginpage)

    return render(request, loginpage)


def logout(request):
    del request.session['email']
    del request.session['name']
    return redirect('index')


def signup(request):
    if request.method == "POST":
        signup_type = request.POST['signup_type']  # Determine the type of signup
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        conpassword = request.POST['password2']
        contact = request.POST['contact']
        address = request.POST['address']
        if password == conpassword:
            if signup_type == "user":
                # Check if the user already exists
                data = userreg.objects.filter(email=email).exists()
                if not data:
                    # Create a new user
                    data_insert = userreg(
                        name=name, email=email, password=password, contact=contact, address=address)
                    data_insert.save()
                    messages.success(request, 'User registered successfully.')
                    return redirect('login')
                else:
                    messages.warning(request, 'User details already exist.')
                    return redirect('signup')
            elif signup_type == "owner":
                # Check if the owner already exists
                data = ownerreg.objects.filter(email=email).exists()  # Assuming ownerreg is the model for owners
                if not data:
                    # Create a new owner
                    data_insert = ownerreg(
                        name=name, email=email, password=password, contact=contact, address=address)
                    data_insert.save()
                    messages.success(request, 'Owner registered successfully.')
                    return redirect('login')
                else:
                    messages.warning(request, 'Owner details already exist.')
                    return redirect('signup')
            else:
                messages.warning(request, 'Invalid signup type.')
                return redirect('signup')
        else:
            messages.error(request, 'Passwords do not match.')
            return redirect('signup')
    return render(request, 'signup.html')  # Render a common signup page

def cloudhome(req):
    return render(req, cloudhomepage)

def viewusers(request):
    usersdata = userreg.objects.filter(status='Deactivated')
    return render(request, viewuseracpt, {'usersdata': usersdata})

# cloud server accept the user request
def acceptuser(request, id):
    data = userreg.objects.get(id=id)
    data.status = 'Activated'
    data.save()
    # Add a success message
    messages.success(request, f'The User "{data.name}" has been successfully activated.')
    return redirect("viewusers")

def viewowners(request):
    ownersdata = ownerreg.objects.filter(status='Deactivated')
    return render(request, viewowneracpt, {'ownersdata': ownersdata})

# cloud server accept the user request
def acceptowner(request, id):
    data = ownerreg.objects.get(id=id)
    data.status = 'Activated'
    data.save()
    # Add a success message
    messages.success(request, f'The owner "{data.name}" has been successfully activated.')
    return redirect("viewowners")

def ownerhome(req):
    return render(req, ownerhomepage)

def userhome(request):
    # Ensure that you retrieve the user's email from the session
    email = request.session.get('email')
    
    if email:
        # Get the user object from the database
        user = userreg.objects.get(email=email)
        # print(99999999,user)
        
        # Pass the user's name to the template
        return render(request, 'userhomepage.html', {'name': user.name})
    else:
        # Handle the case where the user is not logged in or email is not in session
        return redirect('login')  # Redirect to login page



from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import os

# Generate ECC private key
private_key = ec.generate_private_key(ec.SECP256R1())

# Serialize private key to PEM format
private_pem = private_key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.TraditionalOpenSSL,
    encryption_algorithm=serialization.NoEncryption()
)

# Serialize public key to PEM format
public_key = private_key.public_key()
public_pem = public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)

# Encrypt the file data
def encrypt_file(public_key, file_data):
    # Generate a shared key using ECDH (Elliptic Curve Diffie-Hellman)
    shared_key = private_key.exchange(ec.ECDH(), public_key)

    # Derive a symmetric key using PBKDF2HMAC
    salt = os.urandom(16)  # Generate a random salt
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
    )
    key = kdf.derive(shared_key)

    # Pad the file data to match AES block size (128 bits / 16 bytes)
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(file_data) + padder.finalize()

    # Generate random Initialization Vector (IV) for CBC mode
    iv = os.urandom(16)

    # Encrypt the data using AES in CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()

    # Concatenate salt, IV, and encrypted data for decryption
    return salt + iv + encrypted_data


import hashlib

def hash_text(text, algorithm="sha256"):
    return hashlib.new(algorithm, text.encode()).hexdigest()

import uuid
import base64
from django.conf import settings
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import os, time

def uploadfiles(request):
    # TextECCEncryption.objects.all().delete()
    # RequestFiles.objects.all().delete()
    # login = request.session['login']
    email = request.session['email']

    if request.method == 'POST':
        file = request.FILES['file']
        keyword = request.POST['keyword']
        algorithm = request.POST['algorithm']
        keyword_hash = hash_text(keyword)


        upload_folder = os.path.join(settings.BASE_DIR, 'static', 'EnTextFiles')

        if not os.path.exists(upload_folder):
            os.makedirs(upload_folder)

        unique_filename = f"{uuid.uuid4().hex}_{file.name}"

        file_path = os.path.join(upload_folder, unique_filename)
        relative_file_path = os.path.relpath(file_path, settings.BASE_DIR)

        # Save the file to the server (non-encrypted)
        with open(relative_file_path, 'wb') as f:
            for chunk in file.chunks():
                f.write(chunk)

        

        if algorithm == 'ECC':
            with open(relative_file_path, 'rb') as f:
                file_data = f.read()

        # Load the public key
            start = time.time()
            public_key = serialization.load_pem_public_key(public_pem)
            # Read file data and encrypt it
            encrypted_message = encrypt_file(public_key, file_data)
            end = time.time()
            total = end - start
            # Save the encrypted file (overwrite original with encrypted data)
            with open(relative_file_path, 'wb') as f:
                f.write(encrypted_message)

            # Convert encrypted data and keys to base64 strings for storage
            encrypted_data_base64 = base64.b64encode(encrypted_message).decode('utf-8')
            public_key_pem_base64 = base64.b64encode(public_pem).decode('utf-8')
            private_key_pem_base64 = base64.b64encode(private_pem).decode('utf-8')
            # Store the encrypted file data and metadata
            upload = TextECCEncryption.objects.create(
                keyword=keyword,
                keyword_hash=keyword_hash,
                algorithm=algorithm,
                filename=unique_filename,
                encrypted_data=encrypted_data_base64,  # Store base64-encoded encrypted data
                uploader=email,
                file_path=relative_file_path,
                public_key=public_key_pem_base64,  # Save public key as base64 string
                private_key=private_key_pem_base64,  # Save private key as base64 string
                encryption_time=total
            )
            upload.save()

        elif algorithm == 'AES':
            with open(relative_file_path, 'r') as f:
                file_data = f.read()

            start = time.time()
            key = get_random_bytes(16)
            encrypted_message = aes_encrypt(key, file_data)
            end = time.time()
            total = end - start
            # total = round(total, 3)
            # print(total)
            key = key.hex()

            with open(relative_file_path, 'w') as f:
                f.write(encrypted_message)

            upload = TextECCEncryption.objects.create(
                keyword=keyword,
                keyword_hash=keyword_hash,


                algorithm=algorithm,
                filename=unique_filename,
                encrypted_data=encrypted_message,  
                uploader=email,
                file_path=relative_file_path,
                public_key=key,  
                encryption_time=total
            )
            upload.save()

        elif algorithm == 'Quantum':
            with open(relative_file_path, 'r') as f:
                file_data = f.read()

            start = time.time()
            key = create_random_key(len(text_to_binary(file_data)))
            encrypted_message = encrypt_text(file_data, key)
            end = time.time()
            total = end - start
            # total = round(total, 3)
            # print(total)
            # key = key

            with open(relative_file_path, 'w') as f:
                f.write(encrypted_message)

            upload = TextECCEncryption.objects.create(
                keyword=keyword,
                keyword_hash=keyword_hash,


                algorithm=algorithm,
                filename=unique_filename,
                encrypted_data=encrypted_message,  
                uploader=email,
                file_path=relative_file_path,
                public_key=key,  
                encryption_time=total
            )
            upload.save()

        

        messages.success(request, 'File uploaded and encrypted successfully')
        return redirect('uploadfiles')
    return render(request, 'uploadfiles.html')





#view user file 
def viewourfile(request):
    viewfile = TextECCEncryption.objects.filter(uploader=request.session['email'])
    return render(request, 'viewfiles.html', {'data': viewfile})

#view all the uploaded files 
def viewallfile(request):
    data = TextECCEncryption.objects.all()
    return render(request, 'viewallfile.html', {'data': data})

def sendrequest(request,id):
    # login =  request.session['login']
    email =  request.session['email']
    data = TextECCEncryption.objects.get(id=id)
    req = RequestFiles.objects.create(
        file_id = data,
        requester = email
    )
    req.save()
    messages.success(request, 'File Request Sent Successfully!')
    return redirect('viewallfile')
"""
def sendrequest(request, id):
    email = request.session.get('email')

    if not email:
        messages.error(request, "You must be logged in to request files.")
        return redirect('login')

    try:
        data = TextECCEncryption.objects.get(id=id)

        # Ensure the data owner's approval is required before sending a request
        if data.status != 'Approved':  # Check if file status is 'Approved'
            messages.warning(request, "This file is not yet approved by the owner.")
            return redirect('viewallfile')

        # Proceed with sending request if file is approved
        req = RequestFiles.objects.create(file_id=data, requester=email)
        req.save()
        messages.success(request, 'File Request Sent Successfully!')
        return redirect('viewallfile')

    except TextECCEncryption.DoesNotExist:
        messages.error(request, "File does not exist.")
        return redirect('viewallfile')
"""
from django.core.paginator import Paginator


def viewrequests(request):
    # RequestFiles.objects.all().delete()
    # TextECCEncryption.objects.all().delete()

    # login =  request.session['login']
    email =  request.session['email']
    requests = RequestFiles.objects.filter(file_id__uploader=email, status="Pending")

    paginator = Paginator(requests, 4)  # 10 items per page_
    page_number = request.GET.get('page')  # Get the current page number from the GET request
    page_obj = paginator.get_page(page_number)  # Get the page object
    return render(request, 'viewrequests.html', {'data': page_obj})



#view user file 
def viewresponse(request):
    viewfile = RequestFiles.objects.filter(status='keysent',requester=request.session['email'])
    return render(request, viewresponsefile, {'data': viewfile})  



# cloud server accept the user request
def accept(request, id):
    data = RequestFiles.objects.get(id=id)
    data.status = 'Processed'
    data.save()

    messages.success(request, 'Request Processed Successfully!')
    return redirect('viewrequests')


def viewrequestcloud(request):
    viewfiles = RequestFiles.objects.filter(status='Processed')
    return render(request, viewcloudrequset, {'data': viewfiles})
  
from django.core.paginator import Paginator

from django.core.mail import send_mail
import random
def sendkey(request, id):
    data = RequestFiles.objects.get(id=id)
    data.status = 'keysent'
    data.otp = random.randint(100000,999999)
    data.save()
    email_subject = 'Key Details'
    email_message = f'Hello {data.requester},\n\nWelcome To Our Website!\n\nHere are your Key details:\nEmail: {data.requester}\nKey: {data.otp}\n\nPlease keep this information safe.\n\nBest regards,\nYour Website Team'
    send_mail(email_subject, email_message, 'cse.takeoff@gmail.com', [data.requester])
    messages.success(request, 'Key Sent Successfully!')
    return redirect('viewrequestcloud')



import base64
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec

def decrypt_file_data(private_key, encrypted_data, public_key):
    # Decode base64 encoded data
    encrypted_data = base64.b64decode(encrypted_data)
    
    # Extract the salt (16 bytes), IV (16 bytes), and encrypted message
    salt = encrypted_data[:16]  # First 16 bytes are the salt
    iv = encrypted_data[16:32]  # Next 16 bytes are the IV
    encrypted_message = encrypted_data[32:]  # The rest is the encrypted message

    # Derive shared key using the private key and corresponding public key (ECDH)
    shared_key = private_key.exchange(ec.ECDH(), public_key)

    # Derive symmetric AES key using PBKDF2HMAC
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,  # Use the same salt as during encryption
        iterations=100000,
    )
    key = kdf.derive(shared_key)

    # Decrypt the file data using AES in CBC mode
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv))
    decryptor = cipher.decryptor()
    decrypted_data = decryptor.update(encrypted_message) + decryptor.finalize()

    # Unpad the decrypted data
    unpadder = padding.PKCS7(128).unpadder()
    unpadded_data = unpadder.update(decrypted_data) + unpadder.finalize()

    return unpadded_data


def decryptfile(request, id):
    # login = request.session['login']
    # print(id)
    rid =id
    data = RequestFiles.objects.get(id=rid)
    # print(data)
    # print(data.file_id.id)
    if request.method == 'POST':
        key = request.POST['key']
        if data.otp == int(key):
            # fileid = data.file_id.id
            return downloadfile(request,data.file_id.id, id)
            # messages.success(request, 'File Downloaded Successfully!')
            # return redirect('viewresponses')
        else:
            messages.error(request, 'Invalid Key!')
            return redirect('decryptfile',id)
       
    return render(request, 'download.html',{'id':id,'file_name':data.file_id.filename})

    


from django.http import HttpResponse
import base64
from cryptography.hazmat.primitives import serialization

def downloadfile(request, id, rid):
    try:
        # Fetch the encrypted record from the database
        data = RequestFiles.objects.get(id=rid)
        encrypted_record = TextECCEncryption.objects.get(id=id)
        if encrypted_record.algorithm == 'AES':
            key = bytes.fromhex(encrypted_record.public_key)
            # Decrypt the record using the provided key
            start = time.time()
            decrypted_data = aes_decrypt(key, encrypted_record.encrypted_data)
            end = time.time()
            total = end-start
            data.decryption_time = total
            data.save()

        elif encrypted_record.algorithm == 'ECC':   
            # Decode base64-encoded keys and data
            private_key_pem = base64.b64decode(encrypted_record.private_key)
            public_key_pem = base64.b64decode(encrypted_record.public_key)
            encrypted_data = encrypted_record.encrypted_data

            # Load the private and public keys from the PEM data
            private_key = serialization.load_pem_private_key(private_key_pem, password=None)
            public_key = serialization.load_pem_public_key(public_key_pem)
            start = time.time()

            # Decrypt the file data
            decrypted_data = decrypt_file_data(private_key, encrypted_data, public_key)
            end = time.time()
            total = end-start
            data.decryption_time = total
            data.save()
        elif encrypted_record.algorithm == 'Quantum':
            # Decrypt the record using the provided key
            start = time.time()

            decrypted_data = decrypt_text(encrypted_record.encrypted_data, encrypted_record.public_key)
            end = time.time()
            total = end-start
            data.decryption_time = total
            data.save()

        # Send the decrypted text file as an HTTP response
        response = HttpResponse(decrypted_data, content_type='application/octet-stream')
        response['Content-Disposition'] = f'attachment; filename="{encrypted_record.filename}"'
        return response

    except TextECCEncryption.DoesNotExist:
        # Handle file not found in the database
        messages.error(request, "File not found or already deleted.")
        return redirect('decryptfile', rid)

    except Exception as e:
        # Handle general errors during decryption
        messages.error(request, f"An error occurred during decryption: {str(e)}")
        return redirect('decryptfile', rid)


from django.db.models import Q
def decryptiontime(request):
    # login = request.session['login']
    email = request.session['email']
# First, get distinct file IDs where decryption_time is not None
    distinct_file_ids = RequestFiles.objects.filter(~Q(decryption_time=None) & Q(requester = email)).values('file_id').distinct()

    # Then, fetch full records for those file IDs
    data = RequestFiles.objects.filter(file_id__in=[item['file_id'] for item in distinct_file_ids])
    # data=data
    paginator = Paginator(data, 4)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number) 
    return render(request, 'decryptiontime.html',{'data': page_obj,'login':login})



import matplotlib.pyplot as plt
from django.http import HttpResponse
from django.shortcuts import render
from django.conf import settings
from .models import RequestFiles  # Assuming you are using RequestFiles model
import io
import base64

def decryptiongraph(request, id):
    # login = request.session.get('login', None)  # Check if user is logged in
    
    # Fetch the file data from the model
    data = RequestFiles.objects.get(id=id)
    
    # Create a plot comparing encryption and decryption times for the file
    fig, ax = plt.subplots(figsize=(6, 8))  # Adjust figure size if needed
    
    # Data for the bar graph
    times = [data.file_id.encryption_time, data.decryption_time]  # Encryption and Decryption times
    labels = ['Encryption Time', 'Decryption Time']  # Labels for the bars
    
    # Create the bar graph
    ax.bar(labels, times, color=['blue', 'green'])
    
    # Label the axes and add a title
    ax.set_ylabel('Time (seconds)')
    ax.set_title(f'Encryption and Decryption Time Comparison for File: {data.file_id.filename}')
    
    # Improve the appearance of the x-axis labels
    plt.xticks(rotation=0)  # Rotate x-axis labels if needed

    # Save the plot to a BytesIO object
    img_buf = io.BytesIO()
    plt.tight_layout()  # Adjust layout to prevent clipping
    plt.savefig(img_buf, format='png')
    img_buf.seek(0)
    
    # Convert the image to base64
    graph_base64 = base64.b64encode(img_buf.getvalue()).decode('utf-8')

    # Render the template with the file data and the graph
    return render(request, 'decryptiongraph.html', {
        
        'file': data.file_id.filename,
        'encryption_time': data.file_id.encryption_time,
        'decryption_time': data.decryption_time,
        'graph': graph_base64,  # Pass base64-encoded graph
    })









